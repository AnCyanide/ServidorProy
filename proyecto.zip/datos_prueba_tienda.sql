
USE TiendaInstrumentos;

-- Insertar roles
#INSERT INTO Roles(nombre_rol) VALUES 
#('admin'),
#('cliente');

-- Insertar usuarios
-- INSERT INTO Usuarios(nombre, email, id_rol) VALUES
-- ('Administrador', 'admin@tienda.com', 1),
-- ('Carlos Cliente', 'carlos@correo.com', 2);

-- Insertar clientes
INSERT INTO Clientes(nombre, email, direccion) VALUES
('Carlos Cliente', 'carlos@correo.com', 'San José, Costa Rica'),
('Ana Gómez', 'ana@correo.com', 'Heredia, Costa Rica');

-- Insertar productos con precios en colones costarricenses
INSERT INTO Productos(nombre, precio, stock) VALUES
('Batería Acústica Pearl Export', 520000.00, 5),
('Platillos Zildjian A Custom', 310000.00, 10),
('Tambor Tenor Yamaha', 185000.00, 7),
('Baquetas Vic Firth American Classic', 7500.00, 100),
('Cajón Peruano Schlagwerk', 135000.00, 12),
('Conga Meinl Woodcraft', 240000.00, 6),
('Timbales LP Tito Puente', 275000.00, 4),
('Bongos Latin Percussion CP', 95000.00, 15),
('Campana de percusión LP Black Beauty', 38000.00, 20),
('Tambor Requinto', 105000.00, 8);
