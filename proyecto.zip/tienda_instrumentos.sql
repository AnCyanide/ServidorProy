create database TiendaInstrumentos;
USE TiendaInstrumentos;

-- Crear tabla Roles
CREATE TABLE Roles (
    id_rol INT PRIMARY KEY AUTO_INCREMENT,
    nombre_rol VARCHAR(50) NOT NULL UNIQUE
);

-- Crear tabla Usuarios
CREATE TABLE Usuarios (
    id_usuario INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    id_rol INT NOT NULL,
    FOREIGN KEY (id_rol) REFERENCES Roles(id_rol)
);

-- Crear tabla Clientes
CREATE TABLE Clientes (
    id_cliente INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    direccion VARCHAR(200),
    CHECK (email LIKE '%@%')
);

-- Crear tabla Productos
CREATE TABLE Productos (
    id_producto INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    precio DECIMAL(10, 2) NOT NULL CHECK (precio >= 0),
    stock INT NOT NULL CHECK (stock >= 0)
);

-- Crear tabla Pedidos
CREATE TABLE Pedidos (
    id_pedido INT PRIMARY KEY AUTO_INCREMENT,
    id_cliente INT NOT NULL,
    fecha DATETIME NOT NULL DEFAULT NOW(),
    total DECIMAL(10, 2),
    FOREIGN KEY (id_cliente) REFERENCES Clientes(id_cliente)
);

-- Crear tabla DetallesPedido
CREATE TABLE DetallesPedido (
    id_detalle INT PRIMARY KEY AUTO_INCREMENT,
    id_pedido INT NOT NULL,
    id_producto INT NOT NULL,
    cantidad INT NOT NULL CHECK (cantidad > 0),
    precio_unitario DECIMAL(10, 2) NOT NULL CHECK (precio_unitario >= 0),
    FOREIGN KEY (id_pedido) REFERENCES Pedidos(id_pedido),
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
);

-- Insertar roles
INSERT INTO Roles(nombre_rol) VALUES ('admin'), ('cliente');

-- Insertar usuarios
INSERT INTO Usuarios(nombre, email, id_rol) VALUES
('Admin User', 'admin@tienda.com', 1),
('Cliente Uno', 'cliente1@tienda.com', 2);

-- Insertar clientes
INSERT INTO Clientes(nombre, email, direccion) VALUES
('Juan Pérez', 'juan@example.com', 'Calle 123'),
('Ana López', 'ana@example.com', 'Avenida 456');

-- Insertar productos
INSERT INTO Productos(nombre, precio, stock) VALUES
('Batería Acústica', 750.00, 10),
('Platillos Zildjian', 299.99, 15),
('Tambor', 120.50, 20),
('Baquetas de Madera', 12.99, 50);

-- Crear procedimiento CrearPedido
DELIMITER $$

CREATE PROCEDURE CrearPedido(
    IN p_id_cliente INT,
    IN p_productos JSON
)
BEGIN
    DECLARE v_id_pedido INT;
    DECLARE v_total DECIMAL(10,2) DEFAULT 0.0;
    DECLARE v_id_producto INT;
    DECLARE v_cantidad INT;
    DECLARE v_precio_unitario DECIMAL(10,2);
    DECLARE i INT DEFAULT 0;
    DECLARE num_items INT;

    START TRANSACTION;

    INSERT INTO Pedidos(id_cliente, fecha, total)
    VALUES (p_id_cliente, NOW(), 0);

    SET v_id_pedido = LAST_INSERT_ID();
    SET num_items = JSON_LENGTH(p_productos);

    WHILE i < num_items DO
        SET v_id_producto = JSON_UNQUOTE(JSON_EXTRACT(p_productos, CONCAT('$[', i, '].id_producto')));
        SET v_cantidad = JSON_UNQUOTE(JSON_EXTRACT(p_productos, CONCAT('$[', i, '].cantidad')));

        SELECT precio INTO v_precio_unitario
        FROM Productos
        WHERE id_producto = v_id_producto AND stock >= v_cantidad;

        IF v_precio_unitario IS NULL THEN
            ROLLBACK;
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Producto sin stock suficiente o no encontrado';
        END IF;

        UPDATE Productos
        SET stock = stock - v_cantidad
        WHERE id_producto = v_id_producto;

        INSERT INTO DetallesPedido(id_pedido, id_producto, cantidad, precio_unitario)
        VALUES (v_id_pedido, v_id_producto, v_cantidad, v_precio_unitario);

        SET v_total = v_total + (v_precio_unitario * v_cantidad);
        SET i = i + 1;
    END WHILE;

    UPDATE Pedidos
    SET total = v_total
    WHERE id_pedido = v_id_pedido;

    COMMIT;
END$$

DELIMITER ;
USE TiendaInstrumentos;

-- Insertar roles
INSERT INTO Roles(nombre_rol) VALUES 
('admin'),
('cliente');

-- Insertar usuarios
INSERT INTO Usuarios(nombre, email, id_rol) VALUES
('Administrador', 'admin@tienda.com', 1),
('Carlos Cliente', 'carlos@correo.com', 2);

-- Insertar clientes
INSERT INTO Clientes(nombre, email, direccion) VALUES
('Carlos Cliente', 'carlos@correo.com', 'San José, Costa Rica'),
('Ana Gómez', 'ana@correo.com', 'Heredia, Costa Rica');

-- Insertar productos con precios en colones costarricenses
INSERT INTO Productos(nombre, precio, stock) VALUES
('Batería Acústica Pearl Export', 520000.00, 5),
('Platillos Zildjian A Custom', 310000.00, 10),
('Tambor Tenor Yamaha', 185000.00, 7),
('Baquetas Vic Firth American Classic', 7500.00, 100),
('Cajón Peruano Schlagwerk', 135000.00, 12),
('Conga Meinl Woodcraft', 240000.00, 6),
('Timbales LP Tito Puente', 275000.00, 4),
('Bongos Latin Percussion CP', 95000.00, 15),
('Campana de percusión LP Black Beauty', 38000.00, 20),
('Tambor Requinto', 105000.00, 8);

-- ACTUALIZACIONES PARA LA BASE DE DATOS
USE TiendaInstrumentos;

-- Agregar campos para imagen y características
ALTER TABLE Productos 
ADD imagen_url VARCHAR(255) DEFAULT 'https://via.placeholder.com/100',
ADD caracteristicas TEXT;

-- Vista para reporte de ventas
CREATE OR REPLACE VIEW VistaReporteVentas AS
SELECT 
    p.id_pedido,
    c.nombre AS cliente,
    p.fecha,
    dp.id_producto,
    pr.nombre AS producto,
    dp.cantidad,
    dp.precio_unitario,
    (dp.cantidad * dp.precio_unitario) AS subtotal
FROM Pedidos p
JOIN Clientes c ON p.id_cliente = c.id_cliente
JOIN DetallesPedido dp ON p.id_pedido = dp.id_pedido
JOIN Productos pr ON dp.id_producto = pr.id_producto;

use tiendainstrumentos;
ALTER TABLE Usuarios ADD COLUMN password_hash VARCHAR(255);
